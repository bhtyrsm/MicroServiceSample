﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using ContactMicroServices.Interfaces;
using ContactMicroServices.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ContactMicroServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {

        private readonly IContact _contactRepository;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="contactRepository"></param>
        public ContactController(IContact contactRepository)
        {
            _contactRepository = contactRepository;
        }

        /// <summary>
        ///  // GET: api/Contact
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Get()
        {
            var contact = _contactRepository.GetContacts();
            return new OkObjectResult(contact);
        }

        /// <summary>
        ///  GET: api/Contact/5
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}", Name = "Contact")]
        public IActionResult Get(int id)
        {
            var contacts = _contactRepository.GetContactById(id);
            return new OkObjectResult(contacts);
        }

        /// <summary>
        ///  POST: api/Contact
        /// </summary>
        /// <param name="newContact"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Post([FromBody] Contact newContact)
        {
            using (var scope = new TransactionScope())
            {
                _contactRepository.InsertContact(newContact);
                scope.Complete();
                return CreatedAtAction(nameof(Get), new { id = newContact.Id }, newContact);
            }
        }

        // PUT: api/Contact/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Contact updatedContact)
        {
            if (updatedContact != null)
            {
                using (var scope = new TransactionScope())
                {
                    _contactRepository.UpdateContact(updatedContact);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

        /// <summary>
        ///  DELETE: api/ApiWithActions/5
        /// </summary>
        /// <param name="id"></param>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _contactRepository.DeleteContact(id);
            return new OkResult();
        }
    }
}
