﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using ContactMicroServices.Interfaces;
using ContactMicroServices.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ContactMicroServices.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactDetailController : ControllerBase
    {

        private readonly IContactDetail _contactDetailRepository;


        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="contactRepository"></param>
        public ContactDetailController(IContactDetail contactDetailRepository)
        {
            _contactDetailRepository = contactDetailRepository;
        }


        /// <summary>
        /// GET: api/ContactDetail
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Get()
        {
            var contactdetails = _contactDetailRepository.GetContactDetails();
            return new OkObjectResult(contactdetails);
        }

        /// <summary>
        ///  api/ContactDetail/5
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}", Name = "ContactDetail")]
        public IActionResult Get(int id)
        {
            var contactdetails = _contactDetailRepository.GetContactDetailById(id);
            return new OkObjectResult(contactdetails);
        }

        /// <summary>
        /// POST: api/ContactDetail
        /// </summary>
        /// <param name="newContactDetail"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult Post([FromBody] ContactDetail newContactDetail)
        {
            using (var scope = new TransactionScope())
            {
                _contactDetailRepository.InsertContactDetail(newContactDetail);
                scope.Complete();
                return CreatedAtAction(nameof(Get), new { id = newContactDetail.Id }, newContactDetail);
            }
        }

        /// <summary>
        /// PUT: api/ContactDetail/5
        /// </summary>
        /// <param name="id"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] ContactDetail updatedDetail)
        {
            if (updatedDetail != null)
            {
                using (var scope = new TransactionScope())
                {
                    _contactDetailRepository.UpdateContactDetail(updatedDetail);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

        /// <summary>
        ///  DELETE: api/ApiWithActions/5
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _contactDetailRepository.DeleteContactDetail(id);
            return new OkResult();
        }
    }
}
