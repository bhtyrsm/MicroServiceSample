﻿using ContactMicroServices.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactMicroServices.DBContexts
{
    /// <summary>
    /// ContactContext
    /// </summary>
    public class ContactContext : DbContext
    {
        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="options"></param>
        public ContactContext(DbContextOptions<ContactContext> options) :base(options)
        {
        }

        /// <summary>
        /// Contact Model
        /// </summary>
        public DbSet<Contact> Contacts { get; set; }

        /// <summary>
        /// ContactDetail Model
        /// </summary>
        public DbSet<ContactDetail> ContactDetails { get; set; }



    }
}
