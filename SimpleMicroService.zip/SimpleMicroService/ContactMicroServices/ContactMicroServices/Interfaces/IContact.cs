﻿using ContactMicroServices.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactMicroServices.Interfaces
{
    /// <summary>
    /// Contact Interface
    /// </summary>
    public interface IContact
    {
        /// <summary>
        /// GetContactById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Contact GetContactById(int id);

        /// <summary>
        /// GetContacts
        /// </summary>
        /// <returns></returns>
        IEnumerable<Contact> GetContacts();


        /// <summary>
        /// InsertContact
        /// </summary>
        /// <param name="contact"></param>
        void InsertContact(Contact contact);

        /// <summary>
        /// UpdateContact
        /// </summary>
        /// <param name="contact"></param>
        void UpdateContact(Contact contact);

        /// <summary>
        /// DeleteContact
        /// </summary>
        /// <param name="id"></param>
        void DeleteContact(int id);

       

        /// <summary>
        /// Save
        /// </summary>
        void Save();
    }
}
