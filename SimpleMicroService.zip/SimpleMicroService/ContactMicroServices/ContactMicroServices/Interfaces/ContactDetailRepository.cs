﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ContactMicroServices.DBContexts;
using ContactMicroServices.Model;
using Microsoft.EntityFrameworkCore;

namespace ContactMicroServices.Interfaces
{
    /// <summary>
    /// ContactDetailRepository
    /// </summary>
    public class ContactDetailRepository : IContactDetail
    {
        private readonly ContactContext _dbContext;


        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="dbContext"></param>
        public ContactDetailRepository(ContactContext dbContext)
        {
            _dbContext = dbContext;
        }


        /// <summary>
        /// DeleteContactDetail
        /// </summary>
        /// <param name="id"></param>
        public void DeleteContactDetail(int id)
        {
            var contactDetail = _dbContext.ContactDetails.Find(id);
            _dbContext.ContactDetails.Remove(contactDetail);
            Save();
        }

        /// <summary>
        /// GetContactDetailById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ContactDetail GetContactDetailById(int id)
        {
            return _dbContext.ContactDetails.Find(id);
        }

        /// <summary>
        /// GetContactDetails
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ContractDetailViewData> GetContactDetails()
        {
            var result = _dbContext.Contacts
                         .Select(m => new ContractDetailViewData
                         {
                             Name = m.Name,
                             SurName = m.Surname,
                             ContactDetail = _dbContext.ContactDetails.Where(r => r.Contact == m).FirstOrDefault()
                         }).ToList();


            return result;
        }


        /// <summary>
        /// InsertContactDetail
        /// </summary>
        /// <param name="contactdetail"></param>
        public void InsertContactDetail(ContactDetail contactdetail)
        {
            _dbContext.ContactDetails.Add(contactdetail);
            Save();
        }



        /// <summary>
        /// UpdateContactDetail
        /// </summary>
        /// <param name="contactdetail"></param>
        public void UpdateContactDetail(ContactDetail contactdetail)
        {
            _dbContext.Entry(contactdetail).State = EntityState.Modified;
            Save();
        }

        /// <summary>
        /// DeleteContactDetailByContact
        /// </summary>
        /// <param name="contact"></param>
        public void DeleteContactDetailByContact(Contact contact)
        {
            var contactdetail = _dbContext.ContactDetails.Where(r => r.Contact == contact);
            _dbContext.ContactDetails.RemoveRange(contactdetail);
            Save();
        }


        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        {
            _dbContext.SaveChanges();
        }

    }
}
