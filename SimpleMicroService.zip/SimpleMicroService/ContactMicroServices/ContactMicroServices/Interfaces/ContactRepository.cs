﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ContactMicroServices.DBContexts;
using ContactMicroServices.Model;
using Microsoft.EntityFrameworkCore;

namespace ContactMicroServices.Interfaces
{
    /// <summary>
    /// ContactRepository
    /// </summary>
    public class ContactRepository : IContact
    {

        private readonly ContactContext _dbContext;

        /// <summary>
        /// CTOR
        /// </summary>
        /// <param name="dbContext"></param>
        public ContactRepository(ContactContext dbContext)
        {
            _dbContext = dbContext;
        }

        /// <summary>
        /// DeleteContact
        /// </summary>
        /// <param name="id"></param>
        public void DeleteContact(int id)
        {
            var contact = _dbContext.Contacts.Find(id);
            _dbContext.Contacts.Remove(contact);
            Save();
        }



        /// <summary>
        /// GetContactById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Contact GetContactById(int id)
        {
            return _dbContext.Contacts.Find(id);
        }

        /// <summary>
        /// GetContacts
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Contact> GetContacts()
        {
            return _dbContext.Contacts.ToList();
        }

        /// <summary>
        /// InsertContact
        /// </summary>
        /// <param name="contact"></param>
        public void InsertContact(Contact contact)
        {
            _dbContext.Contacts.Add(contact);
            Save();
        }


        /// <summary>
        /// UpdateContact
        /// </summary>
        /// <param name="contact"></param>
        public void UpdateContact(Contact contact)
        {
            _dbContext.Entry(contact).State = EntityState.Modified;
            Save();
        }

       

        /// <summary>
        /// Save
        /// </summary>
        public void Save()
        {
            _dbContext.SaveChanges();
        }

    }
}
