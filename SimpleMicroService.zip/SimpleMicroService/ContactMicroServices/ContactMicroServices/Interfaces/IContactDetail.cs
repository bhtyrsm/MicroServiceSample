﻿using ContactMicroServices.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactMicroServices.Interfaces
{
    /// <summary>
    /// Contact Detail Interface
    /// </summary>
    public interface IContactDetail
    {
        /// <summary>
        /// GetContactDetailById
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        ContactDetail GetContactDetailById(int id);

        /// <summary>
        /// GetContactDetails
        /// </summary>
        /// <returns></returns>
        IEnumerable<ContractDetailViewData> GetContactDetails();



        /// <summary>
        /// InsertContactDetail
        /// </summary>
        /// <param name="contact"></param>
        void InsertContactDetail(ContactDetail contactdetail);

        /// <summary>
        /// UpdateContactDetail
        /// </summary>
        /// <param name="contact"></param>
        void UpdateContactDetail(ContactDetail contactdetail);

        /// <summary>
        /// DeleteContactDetail
        /// </summary>
        /// <param name="id"></param>
        void DeleteContactDetail(int id);

        /// <summary>
        /// DeleteContactDetailByContactId
        /// </summary>
        /// <param name="contactId"></param>
        void DeleteContactDetailByContact(Contact contact);

        /// <summary>
        /// Save
        /// </summary>
        void Save();
    }
}
