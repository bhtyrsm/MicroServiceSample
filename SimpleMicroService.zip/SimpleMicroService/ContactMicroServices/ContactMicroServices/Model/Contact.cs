﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ContactMicroServices.Model
{
    /// <summary>
    /// Contact  Model
    /// </summary>
    [Table("Contact")]
    public class Contact
    {
        /// <summary>
        /// Table Id , Primary Key
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Ad
        /// </summary>
        [Column("Name",TypeName = "nvarchar(100)")]
        [Required]
        public string Name { get; set; }

        /// <summary>
        /// Soyad
        /// </summary>
        [Column("Surname", TypeName = "nvarchar(100)")]
        public string Surname { get; set; }

        /// <summary>
        /// Telefon Numarası  (541 460 11 76)
        /// </summary>
        [Column("PhoneNumber", TypeName = "nvarchar(10)")]
        [Required]
        public string PhoneNumber { get; set; }
        
        /// <summary>
        /// Numara Tipi , 0: ev , 1: iş gibi..
        /// </summary>
        [Column("ContactType")]
        [DefaultValue(0)]
        public int ContactType { get; set; }

        /// <summary>
        /// birincil iletişim tercihi mi ? true , false
        /// </summary>
        [Column("IsPrimary")]
        [Required]
        public bool IsPrimary { get; set; }
    }
}
