﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Threading.Tasks;

namespace ContactMicroServices.Model
{
    /// <summary>
    /// Contact Detail Model
    /// </summary>
    [Table("ContactDetail")]
    public class ContactDetail
    {
        /// <summary>
        /// Tablo Id
        /// </summary>
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        /// <summary>
        /// Ev adresi
        /// </summary>
        [Column("HomeAdress", TypeName = "nvarchar(500)")]
        public string HomeAdress { get; set; }

        /// <summary>
        /// Şirket Adresi
        /// </summary>
        [Column("CompanyAdress", TypeName = "nvarchar(500)")]
        public string CompanyAdress { get; set; }

        /// <summary>
        /// Email Adresi
        /// </summary>
        [Column("Email", TypeName = "nvarchar(25)")]
        public string Email { get; set; }


        /// <summary>
        /// Foreing Key 
        /// </summary>
        public virtual Contact Contact { get; set; }
    }
}
