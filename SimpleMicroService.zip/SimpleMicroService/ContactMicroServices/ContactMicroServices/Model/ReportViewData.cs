﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactMicroServices.Model
{
    /// <summary>
    /// ContractDetailViewData
    /// </summary>
    public class ReportViewData
    {
        public string Location { get; set; }
        public List<string> Persons { get; set; }
    }

    /*
     "Location":"Ümraniye"
     "Persons":"{
                  "Bahtiyar",
                  "Mehmet",
                  "Ali",
                  "Veli"
                }"
     
     */
}
